package brief;

public class Etudiant {
	
	String nom;
	String prenom;
	int noteMaths;
	int noteChimie;
	int noteEconomie;
	
	
	public Etudiant(String nom, String prenom, int noteMaths, int noteChimie, int noteEconomie) {
		this.nom = nom;
		this.prenom = prenom;
		this.noteMaths = noteMaths;
		this.noteChimie = noteChimie;
		this.noteEconomie = noteEconomie;
	}
	
	public Etudiant(String nom, String prenom) {
		this.nom = nom;
		this.prenom = prenom;
		
	}
	
	

	public static void moyenneDesNotes(int noteMaths,int noteChimie, int noteEconomie) {
		
		System.out.println("Votre moyenne génerale est de: "+((noteMaths+noteChimie+noteEconomie)/3));
		
	}
	
	public static void afficherInitiales(String nom,String prenom) {
				
		Etudiant etudiantInitiales = new Etudiant(nom.substring(0, 1), prenom.substring(0, 1));
		
		System.out.println(etudiantInitiales);
	}
	
	
	public static void afficherInitiales2(String nom,String prenom) {
		
		Etudiant etudiantInitiales = new Etudiant(nom.substring(0, 1), prenom.substring(0, 1));
		System.out.println(etudiantInitiales);
	}

	@Override
	public String toString() {
		return "intitiales : " + nom + "." + prenom;
	}
	
	


	
	
	
	
	

}
