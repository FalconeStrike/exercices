package brief;

import java.util.Scanner;

public class main {

	public static void main(String[] args) {
		
		//LES EXERCICES EFFECTUÉS SONT MIS EN COMMENTAIRE.POUR L'UTILISATION DE CHACUNS, VEUILLEZ DÉSACTIVER LES COMMENTAIRES PAR BLOC,MERCI.
		
		/* <----------------------------------------OCCURENCE DE LETTRES-------------------------------------------->
		  
		Scanner scanner = new Scanner(System.in);
		
		System.out.println("Taper un mot");
		
		String mot = scanner.nextLine(); 
		
		int count[] = new int[256]; 
		  
        int len = mot.length(); 
  
        // Initialiser l'index du tableau count
        for (int i = 0; i < len; i++) 
            count[mot.charAt(i)]++; 
 
        char ch[] = new char[mot.length()]; 
        for (int i = 0; i < len; i++) { 
            ch[i] = mot.charAt(i); 
            int occurrence = 0; 
            for (int j = 0; j <= i; j++) { 
                // Vérifier si des correspondances ont été trouvées
                if (mot.charAt(i) == ch[j])
                    occurrence++;                 
            } 
            if (occurrence == 1)  
                System.out.println("Nombre d'occurrences de " + 
                 mot.charAt(i) + " est:" + count[mot.charAt(i)]);             
        } 
        
        */
		
		
		
		
		
		
		/* <----------------------------------------MAJUSCULES ET MINUSCULES-------------------------------------------->

		
		
		
		Scanner scanner = new Scanner(System.in);
		
		System.out.println("Taper un mot");
		
		String mot = scanner.nextLine(); 
	
		System.out.println(mot.toUpperCase());
		System.out.println(mot.toLowerCase());
		
		*/
		
		
		
		
		
		/* <----------------------------------------REMPLACER UNE LETTRE SUR DEUX PAR : "*" -------------------------------------------->

		
Scanner scanner = new Scanner(System.in);
		
		System.out.println("Taper un mot");
		
		String mot = scanner.nextLine(); 
		
		StringBuilder nouveauMot = new StringBuilder(mot);
		
		char[] retour = new char[30];
		nouveauMot.getChars(0, 2,retour, 0);
		
		System.out.println(retour);
		
		*/
		
		
		
		
		
		
		/* <----------------------------------------EXERCICE OBJET LIVRE -------------------------------------------->

		
		Livre monLivre = new Livre("Hugo","Victor","Littérature","1947240277135");
		
		monLivre.afficherCodelivre(monLivre);
		
		*/
		
		
		
		
		
		
		
		/* <----------------------------------------EXERCICE Triangle(non fini) -------------------------------------------->

		
		
		Triangle triangle = new Triangle(12, 10, 4,18);
		
		triangle.calculePerimetre(triangle);
		triangle.calculeAire(triangle);
		triangle.reduirePerimetre(triangle);
		
		*/
		
				
	
	/* <---------------------------------------- EXERCICE MATHS -------------------------------------------->

	Scanner scanner = new Scanner(System.in);
	
	System.out.println("Taper le premier nombre");
	
	int nombre1 = scanner.nextInt();
	
	System.out.println("Taper le deuxième nombre");
	
	int nombre2 = scanner.nextInt();
	
	CalculsMaths.addition(nombre1,nombre2);
	CalculsMaths.multiplication(nombre1,nombre2);
	*/
		
		
		
		
		/* <---------------------------------------- EXERCICE ETUDIANTS -------------------------------------------->
		
		Scanner scanner = new Scanner(System.in);
		
		
		System.out.println("Entrer votre Nom : ");
		
		String nom = scanner.nextLine();
		
		System.out.println("Entrer votre Prénom : ");
		
		String prenom = scanner.nextLine();
		
		System.out.println("Entrer votre note de Mathématiques /20 : ");
		
		int noteMaths = scanner.nextInt();
		
		System.out.println("Entrer votre note de Chimie /20 : ");
		
		int noteChimie = scanner.nextInt();
		
		System.out.println("Entrer votre note d'économie /20 : ");
		
		int noteEconomie = scanner.nextInt();
				
		
		Etudiant.moyenneDesNotes(noteMaths,noteChimie,noteEconomie);
		Etudiant.afficherInitiales(nom,prenom);
		Etudiant.afficherInitiales2(nom, prenom);
		
		*/

		
		}
		
    }
		
		
		
		
		
	


