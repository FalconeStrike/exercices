package brief;

public class Livre {
	
	String titre;
	String nomDeLauteur;
	String prenomDeLauteur;
	String categorie;
	String isbn;
	
	
	

	public Livre(String titre, String nomDeLauteur, String prenomDeLauteur, String categorie, String isbn) {
		this.titre = titre;
		this.nomDeLauteur = nomDeLauteur;
		this.prenomDeLauteur = prenomDeLauteur;
		this.categorie = categorie;
		this.isbn = isbn;
	}
	
	
	public Livre( String nomDeLauteur, String prenomDeLauteur, String categorie,String isbn) {
		this.nomDeLauteur = nomDeLauteur;
		this.prenomDeLauteur = prenomDeLauteur;
		this.categorie = categorie;
		this.isbn = isbn;
	}
	
	public void afficherCodelivre(Livre livre ) {
		
		Livre livreCodeRef = new Livre(nomDeLauteur.substring(0, 2), prenomDeLauteur.substring(0,2), categorie.substring(0, 1),isbn.substring(isbn.length()-2, isbn.length()));
		
		System.out.println(livreCodeRef);
		
	}
	
	@Override
	public String toString() {
		return "Code Nom De L'auteur = " + nomDeLauteur + "\n" + "Code Prénom De Lauteur = " + prenomDeLauteur
				+"\n" + "Code categorie = " + categorie + "\n" + "Code ISBN = "+ isbn;
	}

	
	

}
