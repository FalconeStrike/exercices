package brief;

public class CalculsMaths {
	
	public static void addition(int a, int b) {
		
		System.out.println("l'addition de ces deux nombres est : "+(a+b));
	}
	
public static void multiplication(int a, int b) {
		
		System.out.println("la multiplication de ces deux nombres est : "+(a*b));
	}

}
